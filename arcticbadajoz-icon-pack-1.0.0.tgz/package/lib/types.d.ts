import type { SvgProps } from 'react-native-svg';
export type IconProps = SvgProps & {
    size?: number;
    color?: string;
};
//# sourceMappingURL=types.d.ts.map