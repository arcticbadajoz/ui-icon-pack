import React from 'react';
import type { IconProps } from '../types';
declare const SummaryIcon: ({ color, size, }: IconProps) => React.JSX.Element;
export default SummaryIcon;
//# sourceMappingURL=summary-icon.d.ts.map