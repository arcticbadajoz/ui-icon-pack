import React from 'react';
import type { IconProps } from '../types';
declare const MostActiveIcon: ({ size, color, }: IconProps) => React.JSX.Element;
export default MostActiveIcon;
//# sourceMappingURL=most-active-icon.d.ts.map