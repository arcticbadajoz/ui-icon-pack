import React from 'react';
import type { IconProps } from '../types';
declare const WatchlistIcon: ({ size, color, }: IconProps) => React.JSX.Element;
export default WatchlistIcon;
//# sourceMappingURL=watchlist-icon.d.ts.map