import React from 'react';
import type { IconProps } from '../types';
declare const DownloadIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default DownloadIcon;
//# sourceMappingURL=download-icon.d.ts.map