import React from 'react';
import type { IconProps } from '../types';
declare const SettingsIcon: ({ color, size, outline, }: IconProps & {
    outline?: boolean;
}) => React.JSX.Element;
export default SettingsIcon;
//# sourceMappingURL=settings-icon.d.ts.map