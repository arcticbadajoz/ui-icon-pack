import React from 'react';
import type { IconProps } from '../types';
declare const HomeIcon: ({ size, color, outline, }: IconProps & {
    outline?: boolean;
}) => React.JSX.Element;
export default HomeIcon;
//# sourceMappingURL=home-icon.d.ts.map