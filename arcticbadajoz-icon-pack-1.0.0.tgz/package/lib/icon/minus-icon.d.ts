import React from 'react';
import type { IconProps } from '../types';
declare const MinusIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default MinusIcon;
//# sourceMappingURL=minus-icon.d.ts.map