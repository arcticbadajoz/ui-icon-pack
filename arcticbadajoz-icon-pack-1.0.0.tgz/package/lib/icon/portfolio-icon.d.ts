import React from 'react';
import type { IconProps } from '../types';
declare const PortfolioIcon: ({ size, color, outline, }: IconProps & {
    outline?: boolean;
}) => React.JSX.Element;
export default PortfolioIcon;
//# sourceMappingURL=portfolio-icon.d.ts.map