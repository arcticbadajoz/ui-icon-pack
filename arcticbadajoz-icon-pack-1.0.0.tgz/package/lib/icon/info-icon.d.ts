import React from 'react';
import type { IconProps } from '../types';
declare const InfoIcon: ({ size, color }: IconProps) => React.JSX.Element;
export default InfoIcon;
//# sourceMappingURL=info-icon.d.ts.map