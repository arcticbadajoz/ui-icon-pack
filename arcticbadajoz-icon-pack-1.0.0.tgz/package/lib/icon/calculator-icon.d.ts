import React from 'react';
import type { IconProps } from '../types';
declare const CalculatorIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default CalculatorIcon;
//# sourceMappingURL=calculator-icon.d.ts.map