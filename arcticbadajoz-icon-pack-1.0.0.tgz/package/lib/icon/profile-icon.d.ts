import React from 'react';
import type { IconProps } from '../types';
declare const ProfileIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default ProfileIcon;
//# sourceMappingURL=profile-icon.d.ts.map