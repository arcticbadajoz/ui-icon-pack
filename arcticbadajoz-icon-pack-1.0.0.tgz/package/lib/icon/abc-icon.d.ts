import React from 'react';
import type { IconProps } from '../types';
declare const AbcIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default AbcIcon;
//# sourceMappingURL=abc-icon.d.ts.map