import React from 'react';
import type { IconProps } from '../types';
declare const TrendIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default TrendIcon;
//# sourceMappingURL=trend-icon.d.ts.map