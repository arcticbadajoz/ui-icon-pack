import React from 'react';
import type { IconProps } from '../types';
declare const DividendsIcon: ({ color, size, }: IconProps) => React.JSX.Element;
export default DividendsIcon;
//# sourceMappingURL=dividends-icon.d.ts.map