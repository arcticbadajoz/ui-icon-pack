import React from 'react';
import type { IconProps } from '../types';
declare const MoreIcon: ({ size, color, outline, }: IconProps & {
    outline?: boolean;
}) => React.JSX.Element;
export default MoreIcon;
//# sourceMappingURL=more-icon.d.ts.map