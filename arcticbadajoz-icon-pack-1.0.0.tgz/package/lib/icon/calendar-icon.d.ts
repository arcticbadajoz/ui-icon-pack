import React from 'react';
import type { IconProps } from '../types';
declare const CalendarIcon: ({ size, color, height, }: IconProps & {
    height?: number;
}) => React.JSX.Element;
export default CalendarIcon;
//# sourceMappingURL=calendar-icon.d.ts.map