import React from 'react';
import type { IconProps } from '../types';
declare const RemoveIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default RemoveIcon;
//# sourceMappingURL=remove-icon.d.ts.map