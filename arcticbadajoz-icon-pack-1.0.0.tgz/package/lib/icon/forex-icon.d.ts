import React from 'react';
import type { IconProps } from '../types';
declare const ForexIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default ForexIcon;
//# sourceMappingURL=forex-icon.d.ts.map