import React from 'react';
import type { IconProps } from '../types';
declare const BackIcon: ({ size, color, style, }: IconProps) => React.JSX.Element;
export default BackIcon;
//# sourceMappingURL=back-icon.d.ts.map