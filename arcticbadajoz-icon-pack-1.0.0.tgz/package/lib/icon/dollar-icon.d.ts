import React from 'react';
import type { IconProps } from '../types';
declare const DollarIcon: ({ size, color, style, }: IconProps) => React.JSX.Element;
export default DollarIcon;
//# sourceMappingURL=dollar-icon.d.ts.map