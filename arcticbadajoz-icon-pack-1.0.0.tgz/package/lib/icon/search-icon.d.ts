import React from 'react';
import type { IconProps } from '../types';
declare const SearchIcon: ({ size, color, style, }: IconProps) => React.JSX.Element;
export default SearchIcon;
//# sourceMappingURL=search-icon.d.ts.map