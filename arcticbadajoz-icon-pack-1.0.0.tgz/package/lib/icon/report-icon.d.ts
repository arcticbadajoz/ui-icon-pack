import React from 'react';
import type { IconProps } from '../types';
declare const IdIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default IdIcon;
//# sourceMappingURL=report-icon.d.ts.map