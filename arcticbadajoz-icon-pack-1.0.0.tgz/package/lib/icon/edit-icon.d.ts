import React from 'react';
import type { IconProps } from '../types';
declare const EditIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default EditIcon;
//# sourceMappingURL=edit-icon.d.ts.map