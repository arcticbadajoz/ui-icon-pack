import React from 'react';
import type { IconProps } from '../types';
declare const ChartIcon: React.FC<IconProps>;
export default ChartIcon;
//# sourceMappingURL=chart-icon.d.ts.map