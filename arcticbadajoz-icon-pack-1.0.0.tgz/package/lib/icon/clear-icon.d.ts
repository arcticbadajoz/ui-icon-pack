import React from 'react';
import type { IconProps } from '../types';
declare const ClearIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default ClearIcon;
//# sourceMappingURL=clear-icon.d.ts.map