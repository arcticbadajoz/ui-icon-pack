import React from 'react';
import type { IconProps } from '../types';
declare const MarketIcon: React.FC<IconProps>;
export default MarketIcon;
//# sourceMappingURL=market-icon.d.ts.map