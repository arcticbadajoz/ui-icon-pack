import React from 'react';
import type { IconProps } from '../types';
declare const ChangeIcon: ({ color, size, strokeWidth, }: IconProps & {
    strokeWidth?: number;
}) => React.JSX.Element;
export default ChangeIcon;
//# sourceMappingURL=change-icon.d.ts.map