import React from 'react';
import type { IconProps } from '../types';
declare const BellIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default BellIcon;
//# sourceMappingURL=bell-icon.d.ts.map