import React from 'react';
import type { IconProps } from '../types';
declare const PlusIcon: ({ color, size }: IconProps) => React.JSX.Element;
export default PlusIcon;
//# sourceMappingURL=plus-icon.d.ts.map