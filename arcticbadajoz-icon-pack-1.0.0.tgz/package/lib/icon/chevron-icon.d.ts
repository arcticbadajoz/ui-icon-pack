import React from 'react';
import type { IconProps } from '../types';
declare const ChevronIcon: ({ color, size, }: IconProps) => React.JSX.Element;
export default ChevronIcon;
//# sourceMappingURL=chevron-icon.d.ts.map